﻿using System.ComponentModel.DataAnnotations;

namespace FirstResponsiveWebAppRoney.Models
{
    public class Person
    {
        [Required(ErrorMessage = "Please enter your name.")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Please enter your date of birth.")]
        public DateTime DateOfBirth { get; set; }

        public int CalculateAge()
        {
            int age = 0;
            if (DateTime.Now.Month < DateOfBirth.Month || (DateTime.Now.Month == DateOfBirth.Month && DateTime.Now.Day < DateOfBirth.Day))
            {
                age = DateTime.Now.Year - DateOfBirth.Year - 1;
            }
            else
            {
                age = DateTime.Now.Year - DateOfBirth.Year;
             }
            return age;
        }
    }
}

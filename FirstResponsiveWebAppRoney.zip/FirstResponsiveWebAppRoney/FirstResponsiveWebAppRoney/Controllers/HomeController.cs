﻿using FirstResponsiveWebAppRoney.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace FirstResponsiveWebAppRoney.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        DateOnly DEFAULT_DATE = new DateOnly(2000, 1, 1); // I was not able to declare a DateOnly as constant

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.DateOfBirth = DEFAULT_DATE;
            return View();
        }

        [HttpPost]
        public IActionResult Index(Person model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Age = "Hello " + model.Name + " you are currently " + model.CalculateAge() + " years old.";
                ViewBag.DateOfBirth = model.DateOfBirth;
            }
            else
            {
                ViewBag.DateOfBirth = DEFAULT_DATE;
                ViewBag.Age = 0;
            }
            return View(model);
        }

        //public IActionResult Privacy()
        //{
        //    return View();
        //}

        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        //public IActionResult Error()
        //{
        //    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        //}
    }
}